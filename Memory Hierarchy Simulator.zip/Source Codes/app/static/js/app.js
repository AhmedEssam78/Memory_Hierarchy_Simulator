console.log("Hello I am writing in Javascript WOW!");
